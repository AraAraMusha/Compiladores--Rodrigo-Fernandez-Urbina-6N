from flask import Flask, render_template, request
from lexer import Lexer

app = Flask(__name__)
lexer = Lexer.build()

@app.route('/')
def index():
    return render_template('index.html')


@app.route('/analizar', methods=['POST'])
def analizar():
    Lexer.limpiar()
    entrada_text = request.form['entrada']
    lexer.lineno = 1
    lexer.input(entrada_text)
    tokens = []
    errores = []

    for tok in lexer:
        if tok.type != 'Token_Desconocido':
            tokens.append((tok.type, tok.value, tok.lineno))
        elif tok.type == 'Token_Desconocido':
            errores.append((f" Token no reconocido '{tok.value}'", tok.lineno))

    if Lexer.contador_parentes % 2 != 0:
        errores.append((f" Carácter faltante " + "( o )", 0))    

    if Lexer.contador_llaves % 2 != 0:
            errores.append((f" Carácter faltante " + "{ o }", 0))
    
    for i, line in enumerate(entrada_text.split('\n'), start=1):
            if '("' in line and ';' not in line:
                errores.append((f" Falta ; ", i))
    if not errores: 
            errores.append(("0 errores obtenidos",0))

    return render_template('index.html', tokens=tokens, errores=errores)

if __name__ == '__main__':
    app.run(debug=True)
