import ply.lex as lex

class Lexer:
    tokens = [
        'Delimitador',
        'Operador',
        'Palabra_Res',
        'Entero',
        'Identificador',
        'Punto',
        'Comillas',
        'Abre_Paren',
        'Cierra_Paren',
        'Abre_Corchete',
        'Cierra_Corchete',
        'Abre_Llave',
        'Cierra_Llave',
        'Dos_Puntos',
        'Token_Desconocido'
    ]

    t_ignore = ' \t'

    reserved = {
        'using': 'USING',
        'System': 'SYSTEM',
        'namespace': 'NAMESPACE',
        'class': 'CLASS',
        'static': 'STATIC',
        'void': 'VOID',
        'Main': 'MAIN',
        'string': 'STRING',
        'args': 'ARGS',
        'Console': 'CONSOLE',
        'writeline': 'WRITELINE',
        '!': 'SIGNO_EXCLAMACION'
    }

    tokens += reserved.values()
    contador_lineas = 1
    contador_tokens = {}
    contador_parentesis = 0
    contador_llaves = 0
    contador_parentes = 0
    cantidad_menor = None
    cantidad_menor_1 = None
    cantidad_menor_2 = None

    @staticmethod
    def limpiar():
        Lexer.contador_lineas = 1
        Lexer.contador_tokens = {}
        Lexer.contador_parentesis = 0
        Lexer.contador_llaves = 0
        Lexer.contador_corchetes = 0
        Lexer.cantidad_menor = 0
        Lexer.cantidad_menor_1 = 0
        Lexer.cantidad_menor_2 = 0
        Lexer.tokens = []

    @staticmethod
    def t_Delimitador(t):
        r'[;]'
        return t

    @staticmethod
    def t_Operador(t):
        r'[-+*/=<>]'
        if t.value == '<':
            Lexer.contador_parentesis += 1
        elif t.value == '>':
            Lexer.contador_parentesis -= 1
        return t
    
    @staticmethod
    def t_Palabra_Res(t):
        r'for|static|const|main|class|using|System|namespace|class|void|args|Console|WriteLine|!'
        t.type = Lexer.reserved.get(t.value, 'Palabra_Res')
        return t

    @staticmethod
    def t_Entero(t):
        r'-?\b\d+\b'
        return t



    @staticmethod
    def t_Identificador(t):
        r'\b[a-zA-Z]+\b'
        if t.value == 'suma':
            t.type = 'Identificador'
        elif t.value == 'Hello':
            t.type = 'Identificador'
        elif t.value == 'HelloWorld':
            t.type = 'Identificador'
        elif t.value == 'World':
            t.type = 'Identificador'
        elif t.value == 'Writeline':
            t.type = 'Palabra_Res'
        else:
            t.type = 'Palabra_Res' if t.value in Lexer.reserved else 'Token_Desconocido'
        Lexer.contador_tokens.setdefault(t.type, 0)
        Lexer.contador_tokens[t.type] += 1
        return t

    @staticmethod
    def t_Punto(t):
        r'\.'
        return t

    @staticmethod
    def t_Comillas(t):
        r'\"'
        return t

    @staticmethod
    def t_Abre_Paren(t):
        r'\('
        if t.value == '(':
            Lexer.contador_parentesis += 1
        return t

    @staticmethod
    def t_Cierra_Paren(t):
        r'\)'
        if t.value == ')':
            Lexer.contador_parentesis += 1
        return t

    @staticmethod
    def t_Abre_Corchete(t):
        r'\['
        if t.value == '[':
            Lexer.contador_corchetes += 1
        return t

    @staticmethod
    def t_Cierra_Corchete(t):
        r'\]'
        if t.value == ']':
            Lexer.contador_corchetes += 1
        return t

    @staticmethod
    def t_Abre_Llave(t):
        r'\{'
        if t.value == '{':
            Lexer.contador_llaves += 1
        return t

    @staticmethod
    def t_Cierra_Llave(t):
        r'\}'
        if t.value == '}':
            Lexer.contador_llaves += 1
        return t
    
    @staticmethod
    def t_Dos_Puntos(t):
        r'\:'
        return t

    @staticmethod
    def t_newline(t):
        r'\n+'
        Lexer.contador_lineas += t.value.count('\n')
        t.lexer.lineno += t.value.count('\n')

    @staticmethod
    def t_eof(t):
        t.lexer.lineno += t.value.count('\n')
        return None

    @staticmethod
    def t_error(t):
        print(f"Error léxico: Carácter inesperado '{t.value[0]}' en la línea {Lexer.contador_lineas}")
        t.lexer.skip(1)

    @staticmethod
    def build():
        return lex.lex(module=Lexer())
